let particula;
let particulas=[];

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  for(let i = particulas.length-1; i >=0; i--){
    particulas[i].display();
    particulas[i].update();
    }
  }

//---------Função clique---------
function mouseClicked(){
    particulas.push(new Particle(mouseX, mouseY));
}